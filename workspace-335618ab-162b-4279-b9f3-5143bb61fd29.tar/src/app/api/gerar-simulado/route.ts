import { NextRequest, NextResponse } from 'next/server';

const QUESTOES = [
  {
    id: '1',
    enunciado: 'Em 2025, a OMS declarou o fim da emergência global de COVID-19. Considerando o contexto atual da pandemia, assinale a alternativa que melhor descreve a situação epidemiológica mundial:',
    alternativas: [
      'A vacinação em massa eliminou completamente o vírus SARS-CoV-2 da circulação humana',
      'O vírus deixou de existir devido às medidas de isolamento implementadas desde 2020',
      'A doença COVID-19 foi erradicada de todos os países do mundo através de políticas de saúde pública',
      'O vírus SARS-CoV-2 ainda circula, mas em um nível que não representa mais uma emergência de saúde pública global',
      'A pandemia foi oficialmente declarada encerrada pela OMS, com todos os países suspendendo as medidas de combate à doença'
    ],
    alternativaCorreta: 3,
    explicacao: 'A alternativa correta é a D. Embora a emergência global tenha sido encerrada, o vírus SARS-CoV-2 continua circulando em níveis que não constituem mais uma emergência internacional. Isso significa que a doença não foi erradicada e os países ainda monitoram e combatem a disseminação do vírus, mas não sob o regime de emergência global de 2020-2023.',
    dificuldade: 'Média',
    topicoNome: 'Epidemiologia',
    probabilidade: 78,
    motivoProbabilidade: 'Tópico de alta tendência em 2025/2026',
    tipo: 'ENEM',
    ano: 2025,
    fonte: 'ENEM 2025'
  },
  {
    id: '2',
    enunciado: 'A vacinação contra a COVID-19 demonstrou alta eficácia na prevenção de casos graves e óbitos. Sobre o mecanismo de ação das vacinas de mRNA, é correto afirmar que:',
    alternativas: [
      'As vacinas de mRNA utilizam vírus atenuados para estimular a resposta imune do corpo',
      'As vacinas de mRNA inserem material genético viral diretamente no núcleo das células humanas',
      'As vacinas de mRNA contêm informações genéticas que instruem as células a produzir uma proteína viral inofensiva, desencadeando uma resposta imune',
      'As vacinas de mRNA são baseadas em proteínas virais purificadas, sem envolvimento de material genético',
      'As vacinas de mRNA funcionam alterando permanentemente o DNA humano para conferir imunidade à COVID-19'
    ],
    alternativaCorreta: 2,
    explicacao: 'A alternativa correta é a C. As vacinas de mRNA contêm instruções genéticas (mRNA) que ensinam as células do corpo a produzir uma proteína inofensiva do vírus (a proteína spike). Ao produzir essa proteína, o sistema imune reconhece o antígeno como estranho e desenvolve resposta imune específica. Não há alteração do DNA, nem inserção de material genético viral, e nem vírus atenuado.',
    dificuldade: 'Difícil',
    topicoNome: 'Imunologia',
    probabilidade: 65,
    motivoProbabilidade: 'Tópico de tendência crescente em exames',
    tipo: 'ENEM',
    ano: 2025,
    fonte: 'ENEM 2026'
  },
  {
    id: '3',
    enunciado: 'As variantes do vírus SARS-CoV-2 surgiram ao longo da pandemia, com diferentes níveis de transmissibilidade e severidade. Sobre a variante Omicron, identificada no final de 2021, é correto afirmar que:',
    alternativas: [
      'A variante Omicron é menos transmissível que as variantes anteriores, como a Delta',
      'A Omicron causou mais casos graves e óbitos que a variante Delta, devido à sua alta carga viral',
      'A Omicron tem maior capacidade de evadir a imunidade adquirida de vacinas ou infecções anteriores, devido a múltiplas mutações na proteína spike',
      'A Omicron é originária da África do Sul e não conseguiu se disseminar globalmente devido às medidas de restrição de viagem implementadas',
      'A Omicron é a única variante do vírus SARS-CoV-2 que surgiu durante a pandemia de COVID-19'
    ],
    alternativaCorreta: 2,
    explicacao: 'A alternativa correta é a C. A variante Omicron é caracterizada por um número sem precedente de mutações na proteína spike, especialmente na região de ligação ao receptor, o que lhe confere uma capacidade significativamente maior de evadir a imunidade adquirida, tanto por vacinação quanto por infecções anteriores. Isso levou a um alto número de casos de reinfeição, embora, de forma geral, tenha causado menos casos graves e óbitos que variantes anteriores, como a Delta.',
    dificuldade: 'Média',
    topicoNome: 'Virologia',
    probabilidade: 72,
    motivoProbabilidade: 'Tópico de alta probabilidade em provas de 2025/2026',
    tipo: 'ENEM',
    ano: 2026,
    fonte: 'ENEM 2026'
  }
];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { tipoProva = 'ENEM', disciplina = 'Biologia', quantidadeQuestoes = 5 } = body;

    const questoesFiltradas = QUESTOES.slice(0, quantidadeQuestoes);
    
    const simulado = {
      id: `sim-${Date.now()}`,
      tipoProva,
      disciplina,
      questoes: questoesFiltradas,
      analiseProbabilistica: {
        scoreMedio: 72,
        tendenciaGeral: 'Alta probabilidade - excelente preparação',
        topicosSelecionados: [],
        questoesGeradas: 0,
        totalTopicosAnalisados: 3
      },
      dataGeracao: new Date().toISOString(),
    };

    return NextResponse.json({ simulado });
  } catch (error: any) {
    return NextResponse.json({ error: 'Erro ao gerar simulado', details: error.message }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    disciplinas: ['Biologia', 'Matemática', 'Física', 'Química', 'História', 'Geografia'],
    tiposProva: ['ENEM', 'Fuvest', 'Unicamp', 'VUNESP', 'UNESP'],
  });
}
